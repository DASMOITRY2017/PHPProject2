<?php
session_start();
	 error_reporting(0);
	 include('db.php');
require_once("connection.php");
$session_id=$_SESSION['uid'];
$name=$_SESSION['uname'];
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<title>Profile</title>
	
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet" />
	<link href="assets/css/get-shit-done.css" rel="stylesheet" />  
    <link href="assets/css/demo.css" rel="stylesheet" /> 
    
    <!--     Font Awesome     -->
    <link href="bootstrap3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
	 <style>
	body{ background-color:#480000
	}
	.preview
{
width:200px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}
	#main1 {
		float:left;
		width:300px;
		height:10000px;
		padding:70px;
		
   	    border: 2px solid #480000;
   	    border-top:none;
		 border-top-right-bottom-radius: 2em;
	}
	#main2 {
		float:left;
		width:840px;
		height:10000px;
		padding:70px;
		
		border: 2px solid #480000;
		border-top:none;
			 border-top-right-bottom-radius: 2em;
	}
.fileUpload {
	position: relative;
	overflow: hidden;
	margin: 10px;
}
.fileUpload input.upload {
	position: absolute;
	top: 0;
	right: 0;
	margin: 0;
	padding: 0;
	font-size: 20px;
	cursor: pointer;
	opacity: 0;
	filter: alpha(opacity=0);
}
#postt
{
background-color: white;
   
    padding: 15px;
    border: 0px solid #C8C8C8;
    margin: 5px;
}
	</style>
	
    
</head>
<body >
 <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#101010";>
  <div class="container">
    <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="assets/img/5.jpg" alt="">
                </a>
            </div>
			<div class="navbar-header">
      
       <a class="navbar-brand" href="#">PhotoStrap</a>
	  <ul class="nav navbar-nav">
        <li><a href="home_page3.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
        <li><a href="profile_page.php"><span class="glyphicon glyphicon-th"></span> Profile</a></li>
		 <li><a href="f_list.php"><span class="glyphicon glyphicon-user"></span>My Followers</a></li>
      </ul>
    </div>
    <div>
      <ul class="nav navbar-nav navbar-right">
	     <li><a href="following.php"><span class="glyphicon glyphicon-bell"></span> Following</a></li>
	    <li><a href="editprofilep.php?id=<?php echo urlencode($session_id);?>"><span ></span> Edit Profile</a></li>
        <li><a href="first_page.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

 <br> <br> 

<div class="container">
  <div class="row">
    
    <div class="col-md-12"> 
      
      <div class="panel">
        <div class="panel-body">
          <div class="row"> 
    <div id="main1" style="background-color:#F0F0F0;">
		<div style="width:600px">
<div id='preview'>
<?php	
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic FROM user_table WHERE user_id='$session_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
	echo '<p style="font-size:20px">'.$name.'</p>';
	echo "<img src='uploads/".$row["profile_pic"]."'  class='preview' width='250' height='250' >";
    }
} else {
    echo "0 results";
}
$conn->close();

?>

</div>

<form id="imageform" method="post" enctype="multipart/form-data" action='ajaximage.php'>

   
	<div class="fileUpload btn btn-primary">
    <span>Upload</span>
    <input type="file" class="upload" name="photoimg" id="photoimg" />
</div>
	
</form>
</div>
		

 
		
</div>  

<div id="main2" style="background-color:#F0F0F0;">
<?php
$q="SELECT * FROM post  WHERE user_id='$session_id'";
                        
$r=mysql_query("$q");
if($r)
{
while($row=mysql_fetch_assoc($r))
{
if($row['post_text']==NULL)
{
?>


<a style="font-size:28px;text-decoration:none;color:#000099" href="otherprofile.php?id=<?php echo urlencode($row['user_id']);?>"> <?php echo $row['user_name'];?> </a><br>
<div id="postt">
<img src="public.jpg"  width="70" height="38"><span> <?php echo '&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'
.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'
.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'
.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'
.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'
.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'
.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'
.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp' ?>
<a href="deletepost.php?id=<?php echo urlencode($row['photopost_id']);?>">Delete Post </a></span><p style="font-size:12px;margin:0px;padding:0px;" ><?php echo $row['local'];?></p><br>
<?php 
 
echo '<p style="font-size:20px;margin:0px;padding:0px;" >'.$row['adetails'].'</p>';
echo "</br>";
  echo "<img src=bring_photo.php?ano=".$row['photopost_id']." width=380 height=400/>".'<br>'.'<br>';
  ?></div><?php
  echo '<p style="color:blue;>" >'.$row['count_like']." Likes ".'&nbsp'.'&nbsp'."<span>        ".$row['count_comment']."</span>"." Comments"."<br>"."<br>";
  ?> 
  <a href="viewcomment.php?id=<?php echo urlencode($row['photopost_id']);?>"><b>View All Comments</b></a>
  
  <br>
  <br><br><br><br>
  <?php
}
}
}
else
{ echo mysql_error();}
?>
		
	</div> 
       <!--     <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> -->
          </div>
          
         
          
          
        
          
        </div>
      </div>
                                                                                       
	                                                
                                                      
   	</div><!--/col-12-->
  </div>
</div>


<!-- end main -->
     

</body>

    <script src="jquery/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>

	<script src="bootstrap3/js/bootstrap.js" type="text/javascript"></script>
	<script src="assets/js/gsdk-checkbox.js"></script>
	<script src="assets/js/gsdk-radio.js"></script>
	<script src="assets/js/gsdk-bootstrapswitch.js"></script>
	<script src="assets/js/get-shit-done.js"></script>
	
    <script src="assets/js/custom.js"></script>

	<script type="text/javascript" src="scripts/jquery.min.js"></script>
<script type="text/javascript" src="scripts/jquery.form.js"></script>

<script type="text/javascript">

       $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#preview").html('');
			    $("#preview").html('<img src="loader.gif" alt="Uploading...."/>');
			$("#imageform").ajaxForm({
						target: '#preview'
		}).submit();
		
			});
        });    
    $('.btn-tooltip').tooltip();
    $('.label-tooltip').tooltip();
    $('.pick-class-label').click(function(){
        var new_class = $(this).attr('new-class');  
        var old_class = $('#display-buttons').attr('data-class');
        var display_div = $('#display-buttons');
        if(display_div.length) {
        var display_buttons = display_div.find('.btn');
        display_buttons.removeClass(old_class);
        display_buttons.addClass(new_class);
        display_div.attr('data-class', new_class);
        }
    });
    $( "#slider-range" ).slider({
		range: true,
		min: 0,
		max: 500,
		values: [ 75, 300 ],
	});
	$( "#slider-default" ).slider({
			value: 70,
			orientation: "horizontal",
			range: "min",
			animate: true
	});
	$('.carousel').carousel({
      interval: 4000
    });
      
    
</script>
</html>