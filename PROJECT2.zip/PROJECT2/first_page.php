<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<title>PhotoStrap</title>
	
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet" />
	<link href="assets/css/get-shit-done.css" rel="stylesheet" />  
    <link href="assets/css/demo.css" rel="stylesheet" /> 
    
    <!--     Font Awesome     -->
    <link href="bootstrap3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
	<style>
	</style>
	<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script language="javascript">
    $('.dropdown-toggle').dropdown();
    $('.dropdown-menu').find('form').click(function (e) {
        e.stopPropagation();
      });
</script>
	
    
</head>
<body >

<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#101010";>
  <div class="container">
    <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="assets/img/5.jpg" alt="">
                </a>
            </div>
			<div class="navbar-header">
      
      <a class="navbar-brand" href="#">PhotoStrap</a>
    </div>
    <div>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="signup_page.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
       
		<li class="dropdown" id="menu1">
             <a class="dropdown-toggle" data-toggle="dropdown" href="#menu1">
              <span class="glyphicon glyphicon-log-in"></span> Login
                <b class="caret"></b>
             </a>
             <div class="dropdown-menu">
               <form style="margin: 0px" accept-charset="UTF-8" action="login.php" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="4L/A2ZMYkhTD3IiNDMTuB/fhPRvyCNGEsaZocUUpw40=" /></div>
                 <fieldset class='textbox' style="padding:10px">
                   <input style="margin-top: 12px" name="user_name" type="text" placeholder="Username" />
                   <input style="margin-top: 12px" name="password" type="password" placeholder="Passsword" />
                   <input  class="btn btn-primary btn-fill btn-round" name="commit" type="submit" value="Log In" />
				   
                 </fieldset>
               </form>
             </div>
           </li>
      </ul>
    </div>
  </div>
</nav>
<br> <br> <br> 
<div class="container">
   <div class="row"><br></div>
   <div class="row"><br></div>
   <div class="row"><br></div>

  <div class="row">
    <div class="col-sm-2"> </div>
    <div class="col-sm-8">
<div id="carousel">
    <!--    
            IMPORTANT - This carousel can have a special class for a smooth transition "gsdk-transition". Since javascript cannot be overwritten, if you want to use it, you can use the bootstrap.js or bootstrap.min.js from the GSDKit or you can open your bootstrap.js file, search for "emulateTransitionEnd(600)" and change it with "emulateTransitionEnd(1200)"     
            
    -->
    <div id="carousel-example-generic" class="carousel slide gsdk-transition" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
	
      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <div class="item active">
          <img src="assets/img/1.jpg" alt="Awesome Image">
        </div>
        <div class="item">
          <img src="assets/img/2.jpg" alt="Awesome Image">
        </div>
        <div class="item">
          <img src="assets/img/4.jpg" alt="Awesome Image">
        </div>
      </div>
    
      <!-- Controls -->
      <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
        <span class="fa fa-angle-left"></span>
      </a>
      <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
        <span class="fa fa-angle-right"></span>
      </a>
    </div>
</div> <!-- end carousel -->

  
</div>


<!-- end main -->

</div>
    <div class="col-sm-2"></div>
  </div>
    <div class="row"><br></div>
   <div class="row"><br></div>
</div>   
<br>    
<div class="footer">
    <div class="overlayer">
    <div class="container">
        
            <div class="container">
                
                <div class="row">
                    <div class="col-sm-7">
                        <br>
                        <h3 class="txt-white">Be Social </h3>
                       
<br><br>
                        <a class="btn btn-info  btn-round btn-wd btn-fill social-share social-twitter" href="www.twitter.com"><div class="count" href="www.twitter.com"><i class="fa fa-twitter fa-fw"></i> Tweet </div><div class="share"><span></span></div></a>
                        
                        <a class="btn btn-danger  btn-round btn-wd btn-fill social-share social-twitter" href="www.gmail.com"><div class="count" href="www.gmail.com"><i class="fa fa-google-plus fa-fw"></i> Share </div><div class="share"><span></span></div></a>
                        
                       <a class="btn btn-primary btn-round btn-wd btn-fill social-share" href="www.facebook.com"><div class="count" href="www.facebook.com"><i class="fa fa-facebook fa-fw"></i> Share </div><div class="share"><span></span></div></a>
                       
                       
                    <div class="credits">
                       <i class="fa fa-heart heart" alt="love"></i>   <i class="fa fa-heart heart" alt="love"></i>   <i class="fa fa-heart heart" alt="love"></i>
                    </div>
                    </div>
                    <div class="col-sm-1"></div>
                    <div class="col-sm-4">
                        
                    </div>
                </div>
            </div>
    </div>
    </div>
</div>
</div>
</body>

    <script src="jquery/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>

	<script src="bootstrap3/js/bootstrap.js" type="text/javascript"></script>
	<script src="assets/js/gsdk-checkbox.js"></script>
	<script src="assets/js/gsdk-radio.js"></script>
	<script src="assets/js/gsdk-bootstrapswitch.js"></script>
	<script src="assets/js/get-shit-done.js"></script>
	
    <script src="assets/js/custom.js"></script>

<script type="text/javascript">
         
    $('.btn-tooltip').tooltip();
    $('.label-tooltip').tooltip();
    $('.pick-class-label').click(function(){
        var new_class = $(this).attr('new-class');  
        var old_class = $('#display-buttons').attr('data-class');
        var display_div = $('#display-buttons');
        if(display_div.length) {
        var display_buttons = display_div.find('.btn');
        display_buttons.removeClass(old_class);
        display_buttons.addClass(new_class);
        display_div.attr('data-class', new_class);
        }
    });
    $( "#slider-range" ).slider({
		range: true,
		min: 0,
		max: 500,
		values: [ 75, 300 ],
	});
	$( "#slider-default" ).slider({
			value: 70,
			orientation: "horizontal",
			range: "min",
			animate: true
	});
	$('.carousel').carousel({
      interval: 4000
    });
      
    
</script>
</html>