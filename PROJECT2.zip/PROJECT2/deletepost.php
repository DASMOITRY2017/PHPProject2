<?php
session_start();
require_once('connection.php');
$owner=$_SESSION['uid'];
$pid=$_GET['id'];


$query = "DELETE  FROM post WHERE photopost_id='$pid'";
if( mysql_query($query))
{
  $query1 = "DELETE FROM recent WHERE photopost_id='$pid'";
$res=mysql_query($query1);
		if($res){
header("Location:profile_page.php");
exit;
}
}
?>