<?php
session_start();
require_once('connection.php');
$owner=$_SESSION['uid'];
$cid=$_GET['id'];

$query2="SELECT * from commentofposts  WHERE postcomment_id='$cid'"; 
 $result2=mysql_query($query2);
     $res_list2=mysql_fetch_assoc($result2);
	 
	 $pid=$res_list2['id_post'];


$query = "SELECT * FROM post WHERE photopost_id='$pid'";
 $r=mysql_query($query);
 $res=mysql_fetch_assoc($r);
 $dec=$res['count_comment'];$dec=$dec-1;
 $query1="UPDATE post SET count_comment='$dec' WHERE photopost_id='$pid'";
//echo $query;
if(mysql_query($query1))
{
  $query2 = "DELETE  FROM commentofposts WHERE postcomment_id='$cid'";
if( mysql_query($query2))
{
header("Location:viewcomment.php?id=$pid");
exit;
}
}

?>