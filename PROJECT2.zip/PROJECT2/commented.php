<?php     
require_once('connection.php');
session_start();
	 error_reporting(0);
//ini_set('display_errors',1);
//error_reporting(E_ALL);

$postid=$_GET['p'];
echo $postid;
$me=$_SESSION['uid']; $myname=$_SESSION['uname'];
$comment=$_POST['comment'];
$query="insert into commentofposts
  (id_post,id_user,name_user,text_comment,time) values ('{$postid}','{$me}','{$myname}','{$comment}',CURRENT_TIMESTAMP)";
  
  if(mysql_query($query))
  {
  $q="SELECT * FROM post where photopost_id='$postid'";
$r=mysql_query("$q");
$res=mysql_fetch_assoc($r);
$inc=$res['count_comment'];
$inc=$inc+1;
$query="UPDATE post SET count_comment='$inc' WHERE photopost_id='$postid'";
//echo $query;
if(mysql_query($query))
{
  $query1="insert into recent
  (shown,commented,user_id,user_name,photopost_id) values ('0','1','{$uid}','{$username}','{$postid}')";
   if(mysql_query($query1))
   {
   header("Location:pic_page.php?id=$postid");
exit;

   }
 }
 }
 else{
 echo mysql_error();
 }
 
 