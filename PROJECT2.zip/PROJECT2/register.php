<?php     
require_once('connection.php');
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$repassword=$_POST['repassword'];
$username=$_POST['username'];
$birthday=$_POST['BirthYear'].'-'. $_POST['BirthMonth']."-". $_POST['BirthDay'];
$mobile=$_POST['phone'];
$gender=$_POST['gender'];

$query="SELECT * FROM user_table WHERE email='$email'";
//echo $query;
$result=mysql_query($query);
$row=mysql_fetch_assoc($result);
if($email == $row["email"]){
	echo "Same Password";
     exit;
	
	}	
	else{
	$query="insert into user_table(name,email,user_name,password,birthday,gender,mobile) values('{$name}', '{$email}', '{$username}', '{$password}','{$birthday}','{$gender}','{$mobile}')";
 if(mysql_query($query,$connection))
  {
  $query1="SELECT * from user_table  WHERE name='$name' AND user_name='$username' AND password='$password' AND email='$email'";

 if($result1=(mysql_query($query1,$connection)))
  {
  while($res_list1=mysql_fetch_assoc($result1))
  {
     $owner=$res_list1['user_id']; 
	 echo $owner;
  }
 $query2="SELECT * from user_table  WHERE user_id!='$owner'"; 
 if($result2=mysql_query($query2,$connection)){
     while($res_list2=mysql_fetch_assoc($result2))
	 {
	 $idd=$res_list2['user_id'];
	 echo $idd;
	 $like=$res_list2['totallike'];
	    $query3="insert into unfollowlist(idofowner,nf_id,totallike_nf) values('{$owner}', '{$idd}', '{$like}')";
		mysql_query($query3,$connection);
		$query4="insert into unfollowlist(idofowner,nf_id,totallike_nf) values('{$idd}', '{$owner}', '{$like}')";
		mysql_query($query4,$connection);
	 }
 
 }
  
  
  }
  $query10="insert into messagecount
  (meuser_id,countme) values ('{$owner}','0') ";
  mysql_query($query10);
  }
  

    echo "Successful";
	header("Location: first_page.php"); 
       die("Redirecting to first_page.php"); 
  }
 

	 

?>