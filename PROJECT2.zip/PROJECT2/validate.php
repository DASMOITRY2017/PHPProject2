<?php>
$n=$_POST['comment'];
if($n>10)
{
echo "1";
}
?>