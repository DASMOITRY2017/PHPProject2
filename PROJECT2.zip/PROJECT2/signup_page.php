<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<title>Sign Up</title>
	
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet" />
	<link href="assets/css/get-shit-done.css" rel="stylesheet" />  
    <link href="assets/css/demo.css" rel="stylesheet" /> 
    
    <!--     Font Awesome     -->
    <link href="bootstrap3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
	 <style>
	body{ background-color:#480000
	}
	.signup{

    background:#f1f1f1; width:470px; margin:0 auto; padding-left:50px; padding-top:20px;

}

.signup fieldset{border:0px; padding:0px; margin:0px;}

.signup p.contact { font-size: 12px; margin:0px 0px 10px 0;line-height: 14px; font-family:Arial, Helvetica;}

 

.signup input[type="text"] { width: 400px; }

.signup input[type="email"] { width: 400px; }

.signup input[type="password"] { width: 400px; }

.signup input.birthday{width:60px;}

.signup input.birthyear{width:120px;}

.signup label { color: #000; font-weight:bold;font-size: 12px;font-family:Arial, Helvetica; }

.signup label.month {width: 135px;}

.signup input, textarea { background-color: rgba(255, 255, 255, 0.4); border: 1px solid rgba(122, 192, 0, 0.15); padding: 7px; font-family: Keffeesatz, Arial; color: #4b4b4b; font-size: 14px; -webkit-border-radius: 5px; margin-bottom: 15px; margin-top: -10px; }

.signup input:focus, textarea:focus { border: 1px solid #ff5400; background-color: rgba(255, 255, 255, 1); }

.signup .select-style {

  -webkit-appearance: button;

  -webkit-border-radius: 2px;

  -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);

  -webkit-padding-end: 20px;

  -webkit-padding-start: 2px;

  -webkit-user-select: none;

  background-image: url(images/select-arrow.png),
    -webkit-linear-gradient(#FAFAFA, #F4F4F4 40%, #E5E5E5);

  background-position: center right;

  background-repeat: no-repeat;

  border: 0px solid #FFF;

  color: #555;

  font-size: inherit;

  margin: 0;

  overflow: hidden;

  padding-top: 5px;

  padding-bottom: 5px;

  text-overflow: ellipsis;

  white-space: nowrap;}

.signup .gender {

  width:410px;

  }

.signup input.buttom{ background: #4b8df9; display: inline-block; padding: 5px 10px 6px; color: #fbf7f7; text-decoration: none; font-weight: bold; line-height: 1; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px; -moz-box-shadow: 0 1px 3px #999; -webkit-box-shadow: 0 1px 3px #999; box-shadow: 0 1px 3px #999; text-shadow: 0 -1px 1px #222; border: none; position: relative; cursor: pointer; font-size: 14px; font-family:Verdana, Geneva, sans-serif;}

.signup input.buttom:hover    { background-color: #2a78f6; }

	</style>
	
    
</head>
<body >
<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#101010";>
  <div class="container">
    <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="assets/img/5.jpg" alt="">
                </a>
            </div>
			<div class="navbar-header">
      
       <a class="navbar-brand" href="#">PhotoStrap</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="row">
    
    <div class="col-md-12"> 
      
      <div class="panel">
        <div class="panel-body">   
          <div  class="signup">
		  <form action="register.php" method="post"> 
    		<signup id="contactform"> 
			    <br> <br><br><br><br>
    			<p class="contact"><label for="name">Name</label></p> 
    			<input id="name" name="name" placeholder="First and last name" required tabindex="1" type="text"> 
    			 
    			<p class="contact"><label for="email">Email</label></p> 
    			<input id="email" name="email" placeholder="example@domain.com" required type="email"> 
                
                <p class="contact"><label for="username">Create a username</label></p> 
    			<input id="username" name="username" placeholder="username" required tabindex="2" type="text"> 
    			 
                <p class="contact"><label for="password">Create a password</label></p> 
    			<input type="password" id="password" name="password" required> 
                <p class="contact"><label for="repassword">Confirm your password</label></p> 
    			<input type="password" id="repassword" name="repassword" required> 
        
      <fieldset>
                  <div>
                  <label for="birthday">Birthday</label>

                  <label class="month">

                  <select class="select-style" name="BirthMonth">

                  <option value="">Month</option>

                  <option  value="01">January</option>

                  <option value="02">February</option>

                  <option value="03" >March</option>

                  <option value="04">April</option>

                  <option value="05">May</option>

                  <option value="06">June</option>

                  <option value="07">July</option>

                  <option value="08">August</option>

                  <option value="09">September</option>

                  <option value="10">October</option>

                  <option value="11">November</option>

                  <option value="12" >December</option>

                  </label>

                 </select>   
				 </div>
				 <br>

                <label>Day<input class="birthday" maxlength="2" name="BirthDay"  placeholder="Day" required=""></label>

                <label>Year <input class="birthyear" maxlength="4" name="BirthYear" placeholder="Year" required=""></label>

              </fieldset>

  
            <select class="select-style gender" name="gender">
            <option value="select">i am..</option>
            <option value="m">Male</option>
            <option value="f">Female</option>
            <option value="others">Other</option>
            </select><br><br>
            
            <p class="contact"><label for="phone">Mobile phone</label></p> 
            <input id="phone" name="phone" placeholder="phone number" required type="text"> <br>
            <input class="buttom" name="submit" id="submit" tabindex="5" value="Sign me up!" type="submit"> 	
           </form>			
   </signup> 
</div>

          
         
          
          
        
          
        </div>
      </div>
                                                                                       
	                                                
                                                      
   	</div><!--/col-12-->
  </div>
</div>


<!-- end main -->
<div class="footer">
    <div class="overlayer">
    <div class="container">
        
            <div class="container">
                
                <div class="row">
                    <div class="col-sm-7">
                        <br>
                        <h3 class="txt-white">Be Social </h3>
                       
<br><br>
                        <a class="btn btn-info  btn-round btn-wd btn-fill social-share social-twitter" href="www.twitter.com"><div class="count" href="www.twitter.com"><i class="fa fa-twitter fa-fw"></i> Tweet </div><div class="share"><span></span></div></a>
                        
                        <a class="btn btn-danger  btn-round btn-wd btn-fill social-share social-twitter" href="www.gmail.com"><div class="count" href="www.gmail.com"><i class="fa fa-google-plus fa-fw"></i> Share </div><div class="share"><span></span></div></a>
                        
                       <a class="btn btn-primary btn-round btn-wd btn-fill social-share" href="www.facebook.com"><div class="count" href="www.facebook.com"><i class="fa fa-facebook fa-fw"></i> Share </div><div class="share"><span></span></div></a>
                       
                       
                    <div class="credits">
                       <i class="fa fa-heart heart" alt="love"></i>   <i class="fa fa-heart heart" alt="love"></i>   <i class="fa fa-heart heart" alt="love"></i>
                    </div>
                    </div>
                    <div class="col-sm-1"></div>
                    <div class="col-sm-4">
                        
                    </div>
                </div>
            </div>
    </div>
    </div>
</div>
</div>

     

</body>

    <script src="jquery/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>

	<script src="bootstrap3/js/bootstrap.js" type="text/javascript"></script>
	<script src="assets/js/gsdk-checkbox.js"></script>
	<script src="assets/js/gsdk-radio.js"></script>
	<script src="assets/js/gsdk-bootstrapswitch.js"></script>
	<script src="assets/js/get-shit-done.js"></script>
	
    <script src="assets/js/custom.js"></script>

<script type="text/javascript">
         
    $('.btn-tooltip').tooltip();
    $('.label-tooltip').tooltip();
    $('.pick-class-label').click(function(){
        var new_class = $(this).attr('new-class');  
        var old_class = $('#display-buttons').attr('data-class');
        var display_div = $('#display-buttons');
        if(display_div.length) {
        var display_buttons = display_div.find('.btn');
        display_buttons.removeClass(old_class);
        display_buttons.addClass(new_class);
        display_div.attr('data-class', new_class);
        }
    });
    $( "#slider-range" ).slider({
		range: true,
		min: 0,
		max: 500,
		values: [ 75, 300 ],
	});
	$( "#slider-default" ).slider({
			value: 70,
			orientation: "horizontal",
			range: "min",
			animate: true
	});
	$('.carousel').carousel({
      interval: 4000
    });
      
    
</script>
</html>