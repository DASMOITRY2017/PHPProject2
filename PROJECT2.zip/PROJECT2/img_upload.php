<?php	
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


<?php
$sql = "SELECT profile_pic FROM user_table WHERE user_id='$var'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
	echo "<img src='uploads/".$row["profile_pic"]."'  class='preview' width='250' height='250' >";
    }
} else {
    echo "0 results";
}
$conn->close();
?>