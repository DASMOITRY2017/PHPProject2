<?php
session_start();
require_once('connection.php');
$sender=$_SESSION['uid'];
$rec=$_GET['id'];


$q="insert into followerlist (ownerid,followingid) values ('$sender','$rec')";
$res=mysql_query($q);
		if($res)
	{
	$q1="DELETE FROM unfollowlist WHERE idofowner='$sender' AND nf_id='$rec'";	
		if($res1=mysql_query($q1)){
		 header("Location:home_page3.php");
exit;
		 
		}
	}
?>