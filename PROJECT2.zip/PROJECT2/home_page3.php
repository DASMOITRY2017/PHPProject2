<?php
	 session_start();
	 error_reporting(0);
	 include('db.php');
require_once("connection.php");
$session_id=$_SESSION['uid'];
$name=$_SESSION['uname'];
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<title>Home</title>
	
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet" />
	<link href="assets/css/get-shit-done.css" rel="stylesheet" />  
    <link href="assets/css/demo.css" rel="stylesheet" /> 
    
    <!--     Font Awesome     -->
    <link href="bootstrap3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
	 <style>
	 html
{height:100%;width:100%;}
	
	
	#post {
		float:left;
		width:1140px;
		height:720px;
		padding:70px;
		
		border: 2px solid #606;
		border-top:none;
			 border-top-right-bottom-radius: 2em;
	}
body{ background-color:#480000;height:100%;width:100%;
	}
	.preview
{
width:105px;
border:solid 0px #dedede;
padding:0px;
}
#preview
{
color:#cc0000;
font-size:12px
}
	#main1 {
		float:left;
		width:270px;
        height:20000px;
		padding-top:40px;
		padding:50px;
   	    border: 2px solid #480000;
   	    border-top:none;
		 border-top-right-bottom-radius: 2em;background-color:#F0F0F0";
	}
	#main2 {
		float:left;
		width:870px;
		 height:20000px;
		padding:70px;
		
		border: 2px solid #480000;
		border-top:none;
			 border-top-right-bottom-radius: 2em;background-color:#F0F0F0";
	}
	#one
	{
	width:230px;
	float:left;
	height:100px;
	}
.fileUpload {
	position: relative;
	overflow: hidden;
	margin: 10px;
}
.fileUpload input.upload {
	position: absolute;
	top: 0;
	right: 0;
	margin: 0;
	padding: 0;
	font-size: 20px;
	cursor: pointer;
	opacity: 0;
	filter: alpha(opacity=0);
}
textarea.no
{
  
  width:600px;
  height:150px;
}
#postt
{
background-color: white;
   
    padding: 15px;
    border: 0px solid #C8C8C8;
    margin: 5px;
}


	</style>
	
  <script type="text/javascript">
  function test(a)
  {
  alert(a);
  }
function test(id)
{
$.ajax({
url:"update.php",
type:"POST",
data:{'postid':id},
success:function(data)
{
alert(ok);
}
}
);
}
function pest(form)
{
p=form.a.value;
//pp=id;
alert(p+"moitry");
/*$.ajax({
url:"hoeja.php",
type:"POST",
data:{'postid':id},
success:function(data)
{
alert(ok);
}
}
);*/
}
</script>  
</head>
<body >
<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#101010";>
  <div class="container">
    <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="assets/img/5.jpg" alt="">
                </a>
            </div>
			<div class="navbar-header">
      
       <a class="navbar-brand" href="#">PhotoStrap</a>
	  <ul class="nav navbar-nav">
        <li><a href="home_page3.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
        <li><a href="profile_page.php"><span class="glyphicon glyphicon-th"></span> Profile</a></li>
		 <li><a href="f_list.php"><span class="glyphicon glyphicon-user"></span> My Followers</a></li>
      </ul>
    </div>
    <div>
      <ul class="nav navbar-nav navbar-right">
	    <li><a href="following.php"><span class="glyphicon glyphicon-bell"></span> Following</a></li>
	    <li><a href="recentmessage.php"><span 
		<?php
$q4="SELECT * FROM messagecount where meuser_id='$session_id' ";
$r4=mysql_query($q4);
$res4=mysql_fetch_assoc($r4);
echo '<h1 style="float:right;font-size:20px;">'.$res4['countme'].'</h1>';?>
		
		
		</span> Message</a></li>
        <li><a href="first_page.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<br> <br> <br> 
<div class="container" >
  <div class="row">
    
   <div class="col-md-12"> 
      
      <div class="panel">
        <div class="panel-body">
          <div class="row"> 
    
    <div id="main1" style="background-color:#F0F0F0;">
	<br><br>
	<?php
	
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic FROM user_table WHERE user_id='$session_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row5 = $result->fetch_assoc()) {
	echo "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."<img src='uploads/".$row5["profile_pic"]."'  class='preview' width='8' height='120' >"."&nbsp";
    }
} else {
    echo "0 results";
}
//$conn->close();

?>

	<?php	echo '&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'<p style="font-size:25px;color:blue;">'."&nbsp"."&nbsp".$name.'</p>'; ?>
	<button type="button" class="btn btn-link  btn-lg" style="float:left;" ><span class="glyphicon glyphicon-camera"></span><a href="home_page.php"> upload photo</a></button>
	
		
</div>

<div id="main2"  style="background-color:#F0F0F0">
<p style="color:grey;font:20px;">To get more popular feeds in your homepage Follow more people whose photos get higher responses.</p>
<form style="font-size:14px;color:#000099;" method="post" action="home_page3.php">
                                        <div>
                        <label>Name:<br /></label>
            <input type="text" class="textfield" name="search" value="" size="58" /><br /><br />
                                                <input class="button" type="submit" value="Search" title="Search" />
                                        </div>
                                </form>
								<br>
								<?php 
if(isset($_POST['search'])){
$search = $_POST['search']; //This grabs everything the user has put into the search field (which has been labelled as "search" earlier from the .HTML page).

 


// PHP Search Script
$sql = "select * from user_table where name LIKE '%{$search}%'";
 $result = mysql_query($sql)or die (mysql_error()); 


if (mysql_num_rows($result)==0){ 
echo "No files have been found matching your file name given.<a href='javascript&#058;history.go(-1)'>Go back</a>?";
?>
<br><br>
<?php 
}else{ 
while ($row = mysql_fetch_array($result)){ ?>
<a style="font-size:14px;color:#000099;text-decoration:none;"href="otherprofile.php?id=<?php echo urlencode($row['user_id']);?>"><?php echo $row['name']."<br>";?> </a></br>
<br>
<br>

<?php

 } 
} 
 }
?>		
								
								
								
								
								
								
								
<?php
  $query="SELECT * FROM unfollowlist WHERE idofowner='$session_id' ORDER BY totallike_nf desc LIMIT 0,3";
$row=mysql_query($query);
while($r=mysql_fetch_assoc($row))
{
$idd=$r['nf_id'];
?>

<?php	
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic,user_name FROM user_table WHERE user_id='$idd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row1 = $result->fetch_assoc()) {
	echo "<img src='uploads/".$row1["profile_pic"]."'   width='105' height='100' >"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
	"&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp";
    }
} else {
    //echo "0 results";
}
}
//end of if

?>


<br>
<?php
 $query="SELECT * FROM unfollowlist WHERE idofowner='$session_id' ORDER BY totallike_nf desc LIMIT 0,3";
$row=mysql_query($query);
while($r=mysql_fetch_assoc($row))
{

$id=$r['nf_id'];
$q4="SELECT * FROM user_table WHERE user_id='$id'";
if($r4=mysql_query("$q4"))
{
   while($r5=mysql_fetch_assoc($r4)){
?>

<a style="font-size:12px;text-decoration:none;color:#000099" href="otherprofile.php?id=<?php echo urlencode($r5['user_id']);?>"> <?php echo $r5['name']."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
"&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp";?> </a>
<?php
}
}
}
?>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div>
<?php
$q3="SELECT * FROM recent ORDER BY recent_id DESC LIMIT 0,1
                        ";
$r3=mysql_query("$q3");
if($r3)
{
while($row3=mysql_fetch_assoc($r3))
{
$bring=$row3['photopost_id'];
$q7="SELECT * FROM post WHERE photopost_id='$bring'";
if($r7=mysql_query("$q7"))
{
   while($r17=mysql_fetch_assoc($r7)){
  
if($row3['liked']==1){?>
<p style="font-size:15px;text-decoration:none;color:#000099">
<a style="font-size:18px;color:#000099" href="otherprofile.php?id=<?php echo urlencode($row3['user_id']);?>"><?php echo $row3['user_name']."&nbsp";?></a><?php echo " liked this post from ".$r17['local'];?><br><br><br>
<span id='preview'>
<?php
$idd=$r17['user_id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic FROM user_table WHERE user_id='$idd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row5 = $result->fetch_assoc()) {
	echo "&nbsp"."&nbsp"."<img src='uploads/".$row5["profile_pic"]."'  class='preview' width='5' height='80' >"."&nbsp";
    }
} else {
    echo "0 results";
}
//$conn->close();

?>

</span>  
<?php	
if($r17['post_text']==NULL)
{
?>


<a style="font-size:28px;text-decoration:none;color:#000099" href="otherprofile.php?id=<?php echo urlencode($r17['user_id']);?>"> <?php echo $r17['user_name'];?> </a><br>
<div id="postt">
<img src="public.jpg"  width="70" height="38"><p style="font-size:12px;margin:0px;padding:0px;" ><?php echo $r17['local'];?></p><br>
<?php 
 
echo '<p style="font-size:20px;margin:0px;padding:0px;" >'.$r17['adetails'].'</p>';
echo "</br>";?>
<a href="pic_page1.php?id=<?php echo $r17['photopost_id']; ?>">
<?php
  echo "<img src=bring_photo.php?ano=".$r17['photopost_id']." width=380 height=400/>".'<br>'.'<br>';
 ?>
 </a>
 </div>
 
 <?php
 echo '<p style="color:blue;">'." ".$r17['count_like'];
 ?>
  
  <a href="wholike.php?id=<?php echo $r17['photopost_id']; ?>" style="font-size:15px;color:blue;" >Likes</a><?php echo '&nbsp'.'&nbsp'."<span>        ".$r17['count_comment']."</span>"." Comments"."&nbsp"."&nbsp".$r17['count_views']." Views"."&nbsp"."&nbsp".$r17['count_share']."&nbsp"."<br>"."<br>";
  }



}
 else if($row3['commented']==1){?>
  <p style="font-size:15px;text-decoration:none;color:#000099">
 <a style="font-size:18px;color:#000099" href="otherprofile.php?id=<?php echo urlencode($row3['user_id']);?>"><?php echo $row3['user_name']."&nbsp";?></a><?php echo "commented on this post from ".$r17['local'];?><br><br><br>
 <span id='preview'>
<?php
$idd=$r17['user_id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic FROM user_table WHERE user_id='$idd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row5 = $result->fetch_assoc()) {
	echo "&nbsp"."&nbsp"."<img src='uploads/".$row5["profile_pic"]."'  class='preview' width='5' height='80' >"."&nbsp";
    }
} else {
    echo "0 results";
}
//$conn->close();

?>

</span>  
<?php	
if($r17['post_text']==NULL)
{
?>


<a style="font-size:28px;text-decoration:none;color:#000099" href="otherprofile.php?id=<?php echo urlencode($r17['user_id']);?>"> <?php echo $r17['user_name'];?> </a><br>
<div id="postt">
<img src="public.jpg"  width="70" height="38"><p style="font-size:12px;margin:0px;padding:0px;" ><?php echo $r17['local'];?></p><br>
<?php 
 
echo '<p style="font-size:20px;margin:0px;padding:0px;" >'.$r17['adetails'].'</p>';
echo "</br>";?>
<a href="pic_page1.php?id=<?php echo $r17['photopost_id']; ?>">
<?php
  echo "<img src=bring_photo.php?ano=".$r17['photopost_id']." width=380 height=400/>".'<br>'.'<br>';
 ?>
 </a>
 </div>
 
 <?php
 echo '<p style="color:blue;">'." ".$r17['count_like'];
 ?>
  
  <a href="wholike.php?id=<?php echo $r17['photopost_id']; ?>" style="font-size:15px;color:blue;" >Likes</a><?php echo '&nbsp'.'&nbsp'."<span>        ".$r17['count_comment']."</span>"." Comments"."&nbsp"."&nbsp".$r17['count_views']." Views"."&nbsp"."&nbsp".$r17['count_share']."&nbsp"."Shares"."<br>"."<br>";
  }

$s1="SELECT * FROM commentofposts where id_post='$bring' ORDER BY postcomment_id desc LIMIT 0,1";
$m=mysql_query("$s1");
while($sow=mysql_fetch_assoc($m))
{
?>
<div class="panel panel-default">

  <div class="panel-heading">
  <a href="otherprofile.php?id=<?php echo $sow['id_user'] ?>"><?php echo $sow['name_user']; ?></a></div>
  <div class="panel-body">
<?php echo $sow['text_comment']; ?>

<p class="text-muted small" style="padding-top:15px"><?php 
$d=(strtotime($sow['time']));
 echo date('d ',$d);
echo date('F,Y',$d);
echo " at ";
echo date('h:m:s',$d);

?></p>
  </div>
</div>
<?php
// var_dump($comment);
}
 
 
 
 
 
 }?></p>
  <?php
}
}
}
}
?>
</div>
<br>
<br><br><br><br><br><br><br>

<?php
$q3="SELECT * FROM share ORDER BY sharepost_id DESC LIMIT 0,1
                        ";
$r3=mysql_query("$q3");
if($r3)
{
while($row3=mysql_fetch_assoc($r3))
{
$whose_id=$row3['whosepost_id'];
$whose_name=$row3['whosepost_name'];
$whoname=$row3['whoshared_name'];
$whoid=$row3['whoshared_id'];
$poid=$row3['sharedid'];?>
<a style="font-size:18px;color:#000099" href="otherprofile.php?id=<?php echo urlencode($row3['whoshared_id']);?>"><?php echo $whoname;?></a><?php echo "&nbsp"."   Shared "."&nbsp"."&nbsp";?>
<a style="font-size:18px;color:#000099" href="otherprofile.php?id=<?php echo urlencode($row3['whosepost_id']);?>"><?php echo $whose_name;?></a><?php echo"&nbsp"." 's post";?><br><br><br>
<?php
$q71="SELECT * FROM post WHERE photopost_id='$poid'";
if($r71=mysql_query("$q71"))
{
   while($r71=mysql_fetch_assoc($r71)){
   $uff=$r71[user_id];
   $servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic FROM user_table WHERE user_id='$idd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row5 = $result->fetch_assoc()) {
	echo "&nbsp"."&nbsp"."<img src='uploads/".$row5["profile_pic"]."'  class='preview' width='5' height='80' >"."&nbsp";
    }
} else {
    echo "0 results";
}
//$conn->close();

?>

</span>  
<?php	
if($r71['post_text']==NULL)
{
?>


<a style="font-size:28px;text-decoration:none;color:#000099" href="otherprofile.php?id=<?php echo urlencode($r71['user_id']);?>"> <?php echo $r71['user_name'];?> </a><br>
<div id="postt">
<img src="public.jpg"  width="70" height="38"><p style="font-size:12px;margin:0px;padding:0px;" ><?php echo $r71['local'];?></p><br>
<?php 
 
echo '<p style="font-size:20px;margin:0px;padding:0px;" >'.$r71['adetails'].'</p>';
echo "</br>";?>
<a href="pic_page1.php?id=<?php echo $r71['photopost_id']; ?>">
<?php
  echo "<img src=bring_photo.php?ano=".$r71['photopost_id']." width=380 height=400/>".'<br>'.'<br>';
 ?>
 </a>
 </div>
 
 <?php
 echo '<p style="color:blue;">'." ".$r71['count_like'];
 ?>
  
  <a href="wholike.php?id=<?php echo $r71['photopost_id']; ?>" style="font-size:15px;color:blue;" >Likes</a><?php echo '&nbsp'.'&nbsp'."<span>        ".$r71['count_comment']."</span>"." Comments"."&nbsp"."&nbsp".$r71['count_views']." Views"."&nbsp"."&nbsp".$r71['count_share']." Shares"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>";
  }


  }
}

}
}

$q="SELECT * FROM post ORDER BY photopost_id DESC 
                        ";
$r=mysql_query("$q");
if($r)
{
while($row=mysql_fetch_assoc($r))
{
$idd=$row['user_id'];
?>

<span id='preview'>

<?php
$q1="SELECT * FROM followerlist WHERE ownerid=$session_id";
if($r1=mysql_query("$q1"))
{
   while($row1=mysql_fetch_assoc($r1))
   {
      if($row1['followingid']==$idd){
	  $servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic FROM user_table WHERE user_id='$idd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row5 = $result->fetch_assoc()) {
	echo "&nbsp"."&nbsp"."<img src='uploads/".$row5["profile_pic"]."'  class='preview' width='5' height='80' >"."&nbsp";
    }
} else {
    echo "0 results";
}
//$conn->close();

?>

</span>  
<?php

if($row['post_text']==NULL)
{
?>


<a style="font-size:28px;text-decoration:none;color:#000099" href="otherprofile.php?id=<?php echo urlencode($row['user_id']);?>"> <?php echo $row['user_name'];?> </a><br>
<div id="postt">
<img src="public.jpg"  width="70" height="38"><p style="font-size:12px;margin:0px;padding:0px;" ><?php echo $row['local'];?></p><br>
<?php 
 
echo '<p style="font-size:20px;margin:0px;padding:0px;" >'.$row['adetails'].'</p>';
echo "</br>";?>
<a href="pic_page1.php?id=<?php echo $row['photopost_id']; ?>">
<?php
  echo "<img src=bring_photo.php?ano=".$row['photopost_id']." width=380 height=400/>".'<br>'.'<br>';
 ?>
 </a>
 </div>

 <?php
  echo '<p style="color:blue;">'." ".$row['count_like'];?>
  
  <a href="wholike.php?id=<?php echo $row['photopost_id']; ?>" style="font-size:15px;color:blue;" >Likes</a><?php echo '&nbsp'.'&nbsp'."<span>        ".$row['count_comment']."</span>"." Comments"."&nbsp"."&nbsp".$row['count_views']." Views"."&nbsp"."&nbsp".$row['count_share']."&nbsp"."Shares"."<br>"."<br>";
  $potaka=1;
  if($row['count_comment']<=2)
  {
  $potaka=0;
  }
  ?> 
   <div id="partial">
  <?php if($potaka==1){ ?>
  <p >Top Comments <?php echo '&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'?> <span> <a href="pic_page1.php?id=<?php echo $row['photopost_id']; ?>" style="font-size:15px;" >View All Comments</a> </span></p><?php } ?>
  <?php
  
  $pid=$row['photopost_id'];
$s1="SELECT * FROM commentofposts where id_post='$pid' ORDER BY postcomment_id desc LIMIT 0,2";
$m=mysql_query("$s1");
while($sow=mysql_fetch_assoc($m))
{
?>
<div class="panel panel-default">

  <div class="panel-heading">
  <a href="otherprofile.php?id=<?php echo $sow['id_user'] ?>"><?php echo $sow['name_user']; ?></a></div>
  <div class="panel-body">
<?php echo $sow['text_comment']; ?>

<p class="text-muted small" style="padding-top:15px"><?php 
$d=(strtotime($sow['time']));
 echo date('d ',$d);
echo date('F,Y',$d);
echo " at ";
echo date('h:m:s',$d);

?></p>
  </div>
</div>
<?php
// var_dump($comment);
}

?>

  </div>
  
  
  
  
  <br>
  <br><br><br><br>
  
  <?php
}
	  //pp
	  }
   }
}
}
}?>
	</div> 
       <!--     <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> -->
          </div>
          
         
          
          
        
          
        </div>
      </div>
                                                                                       
	                                                
                                                      
   	</div><!--/col-12-->
  </div>
</div>


<!-- end main -->
     

</body>

    <script src="jquery/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>

	<script src="bootstrap3/js/bootstrap.js" type="text/javascript"></script>
	<script src="assets/js/gsdk-checkbox.js"></script>
	<script src="assets/js/gsdk-radio.js"></script>
	<script src="assets/js/gsdk-bootstrapswitch.js"></script>
	<script src="assets/js/get-shit-done.js"></script>
	
    <script src="assets/js/custom.js"></script>

<script type="text/javascript">
         
    $('.btn-tooltip').tooltip();
    $('.label-tooltip').tooltip();
    $('.pick-class-label').click(function(){
        var new_class = $(this).attr('new-class');  
        var old_class = $('#display-buttons').attr('data-class');
        var display_div = $('#display-buttons');
        if(display_div.length) {
        var display_buttons = display_div.find('.btn');
        display_buttons.removeClass(old_class);
        display_buttons.addClass(new_class);
        display_div.attr('data-class', new_class);
        }
    });
    $( "#slider-range" ).slider({
		range: true,
		min: 0,
		max: 500,
		values: [ 75, 300 ],
	});
	$( "#slider-default" ).slider({
			value: 70,
			orientation: "horizontal",
			range: "min",
			animate: true
	});
	$('.carousel').carousel({
      interval: 4000
    });
      
    
</script>
</html>