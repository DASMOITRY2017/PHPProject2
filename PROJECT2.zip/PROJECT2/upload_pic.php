<?php
	 session_start();
?>
<?php
ini_set('display_errors',1);
error_reporting(E_ALL);
require_once("connection.php");
$session_id=$_SESSION['uid'];
$session_name=$_SESSION['uname'];
$imagedes=$_POST['imagedes'];
$adetails=$_POST['adetails'];
$aphoto=addslashes (file_get_contents($_FILES['aphoto']['tmp_name']));
$image = getimagesize($_FILES['aphoto']['tmp_name']);
$imgtype=$image['mime'];
$q="insert into post(user_id,user_name,adetails,aphoto,aphototype,local,flag) values('$session_id','$session_name','$imagedes','$aphoto','$imgtype',CURRENT_TIMESTAMP,'1')";
$r=mysql_query($q);
if($r)
{
 header("Location:home_page3.php");
exit;
}
else
{
   echo mysql_error();
}

?>