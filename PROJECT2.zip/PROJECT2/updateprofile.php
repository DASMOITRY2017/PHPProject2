<?php
session_start();
	 error_reporting(0);
	 include('db.php');
require_once("connection.php");
$session_id=$_SESSION['uid'];
$name=$_SESSION['uname'];

if(isset($_POST['fname'])||!empty($_POST['fname']))
{
$name=$_POST['fname'];
$q="UPDATE user_table SET name='{$name}' where user_id={$session_id}"; 
if (mysql_query($q))
{
    header("Location:editprofilep.php");
exit;
}

}
if(isset($_POST['bday'])||!empty($_POST['bday']))
{
$bd=$_POST['bday'];
$q="UPDATE user_table SET birthday='{$bd}' where user_id={$session_id}"; 
if (mysql_query($q))
{
    header("Location:editprofilep.php");
exit;
}

}
if(isset($_POST['add'])||!empty($_POST['add']))
{
$add=$_POST['add'];
$q="UPDATE user_table SET address='{$add}' where user_id={$session_id}"; 
if (mysql_query($q))
{
    header("Location:editprofilep.php");
exit;
}

}
if(isset($_POST['pwd'])||!empty($_POST['pwd']))
{
$phone=$_POST['pwd'];
$q="UPDATE user_table SET password='{$phone}' where user_id={$session_id}"; 
if (mysql_query($q))
{
    header("Location:editprofilep.php");
exit;
}

}
if(isset($_POST['aboutme'])||!empty($_POST['aboutme']))
{
$ab=$_POST['aboutme'];
$q="UPDATE user_table SET about_me='{$ab}' where user_id={$session_id}"; 
if (mysql_query($q))
{
    header("Location:editprofilep.php");
exit;
}

}
?>