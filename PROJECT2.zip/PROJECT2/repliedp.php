<?php session_start();
	 error_reporting(0);
	 include('db.php');
require_once("connection.php");
$session_id=$_SESSION['uid'];
$name=$_SESSION['uname'];
$var=$_GET['id'];


$sharedpost=$_POST['mas'];



$q3="SELECT * FROM user_table where user_id='$session_id'";
$r3=mysql_query("$q3");
$row3=mysql_fetch_assoc($r3);
$senfname=$row3['name'];


$q4="SELECT * FROM user_table where user_id='$var'";
$r4=mysql_query("$q4");
$row4=mysql_fetch_assoc($r4);
$refname=$row4['name'];


$query="insert into recentmessage (sender_id,receiver_id,textme,timeofsend,sender_name,receiver_name,seen) values ('$session_id','$var','$sharedpost',CURRENT_TIMESTAMP,'$senfname','$refname','0')";
  
  if(mysql_query($query))
  {
    $query1="insert into message (senderid,receiverid,me,time,sendername,receivername) values ('$session_id','$var','$sharedpost',CURRENT_TIMESTAMP,'$senfname','$refname')";
	if(mysql_query($query1))
	{
	$q="SELECT * FROM messagecount where meuser_id='$var'";
$r=mysql_query("$q");
$res=mysql_fetch_assoc($r);
$inc=$res['countme'];
$inc=$inc+1;
$sql="UPDATE messagecount SET countme='$inc' WHERE meuser_id='$var'";
if(mysql_query($sql))
{
header("Location:recentmessage.php?id=$var");
exit;
}

	}
  }
  else
  { 
    echo "<p>Failed</p>";
	echo "<p>".mysql_error()."</p>";
  }
  
 
  


?>