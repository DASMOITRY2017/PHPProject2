 <?php     
require_once('connection.php');
session_start();
	 error_reporting(0);
$me=$_SESSION['uid']; $myname=$_SESSION['uname'];
$postid=$_GET['id'];
$q="SELECT * FROM post where photopost_id='$postid'";
$r=mysql_query("$q");
$res=mysql_fetch_assoc($r);
$inc=$res['count_like'];
$inc=$inc+1;
$query="UPDATE post SET count_like='$inc' WHERE photopost_id='$postid'";
//echo $query;
if(mysql_query($query))
{
   $userid=$res['user_id'];
  $q1="SELECT * FROM user_table where user_id='$userid'";
$r1=mysql_query("$q1");
$res1=mysql_fetch_assoc($r1);
$inc1=$res1['totallike'];
$inc1=$inc1+1;
$query1="UPDATE user_table SET totallike='$inc1' WHERE user_id='$userid'";
if(mysql_query($query1))
{
  $q2="SELECT * FROM unfollowlist where nf_id='$userid'";
$r2=mysql_query("$q2");
$res2=mysql_fetch_assoc($r2);
$inc2=$res2['totallike_nf'];
$inc2=$inc2+1;
$query2="UPDATE unfollowlist SET totallike_nf='$inc2' WHERE nf_id='$userid'";
  if(mysql_query($query2)){
   
}
}
}
  else
  { 
    echo "<p>Failed</p>";
	echo "<p>".mysql_error()."</p>";
  }

	 

?>
<?php
$query="insert into uff
  (ufflike,uffpostid) values ('{$me}','{$postid}')";
  
  if(mysql_query($query))
  {
    $query1="insert into recent
  (shown,liked,user_id,user_name,photopost_id) values ('0','1','{$me}','{$myname}','{$postid}')";
   if(mysql_query($query1))
   {
   header("Location:pic_page1.php?id=$postid");
exit;

   }
  
  }


?>