<?php
 require_once('connection.php');
session_start();
	 //error_reporting(0);
?>
<?php

$postid=$_POST['postid'];
//echo $n." ";
$comment=addslashes($_POST['commentarea']);
$id=$_SESSION['uid'];
$name=$_SESSION['uname'];
//echo $id." ";
$q="insert into commentofposts (id_post,id_user,name_user,text_comment,time) VALUES ('".$postid."','".$id."','".$name."','".$comment."',CURRENT_TIMESTAMP)";
if(mysql_query($q))
{
$q1="SELECT * FROM post where photopost_id='$postid'";
$r1=mysql_query("$q1");
$res1=mysql_fetch_assoc($r1);
$inc=$res1['count_comment'];
$inc=$inc+1;
$query="UPDATE post SET count_comment='$inc' WHERE photopost_id='$postid'";
//echo $query;
if(mysql_query($query))
{
  $query1="insert into recent
  (shown,commented,user_id,user_name,photopost_id) values ('0','1','{$id}','{$name}','{$postid}')";
   if(mysql_query($query1))
   {
   //header("Location:pic_page.php?id=$postid");
//exit;

   }
 }
}


/*if(!$result)
echo mysql_error()." Error Submitting.";
else
{
header('location:home_page4.php');
}

?>
<?php*/
?>

<div class="panel panel-default">
  <div class="panel-heading">
  <a href="publicprofile.php?id=<?php echo $id; ?>"><?php echo $name; ?></a></div>
  <div class="panel-body">
<?php echo $comment; ?>

<p class="text-muted small" style="padding-top:15px"><?php 
//$d=(strtotime($comment['time']));
date_default_timezone_set('Asia/Dhaka');
 echo date('d ');
echo date('F,Y');
echo " at ";
echo date('h:m:s');

?></p>
  </div>
</div>
<?php 
mysql_close(); ?>
