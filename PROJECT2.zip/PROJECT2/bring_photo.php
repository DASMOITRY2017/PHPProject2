<?php
ini_set('display_errors',1);
error_reporting(E_ALL);
include("connection.php"); 
$ano=$_GET['ano'];
$q="SELECT aphoto,aphototype from post where photopost_id='$ano'";
$r=mysql_query($q);
if($r)
{
$row=mysql_fetch_array($r);
$type="content-type: ".$row['aphototype'];
header($type);
echo $row['aphoto'];
}
else
{
echo mysql_error();
}

?>