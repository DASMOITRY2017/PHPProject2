<?php
session_start();
require_once('connection.php');
$session_id=$_SESSION['uid'];
$i=1;
$arr[$i]=9;
$flag=7;
$query="SELECT * FROM post where user_id!='0' ORDER BY count_like desc LIMIT 0,5";
$row=mysql_query($query);
while($r=mysql_fetch_assoc($row))
{
//$arr[$i]=$r['count_like'];
echo $r['count_like'];
//echo $arr[$i];
//$i++;
}


$flag5=0;$p=0;$arr[3]=0;
while($p==0){
echo $flag5;
  $query="SELECT * FROM post where user_id!='$flag5' ORDER BY count_like desc LIMIT 0,3";
$row=mysql_query($query);
$po=0;
while($r=mysql_fetch_assoc($row))
{
$p=1;
$idd=$r['user_id'];$arr[$po]=$r['user_id'];
$q3="SELECT * FROM followerlist WHERE ownerid=$session_id";
if($r3=mysql_query("$q3"))
{
$flag=0;
   while($row3=mysql_fetch_assoc($r3))
   {
      if($row3['followingid']==$idd){
	  $flag5=$idd;
	  $flag=1;
	  break;
	  }
   }
   if($flag==1)
   {
   $p=0;
   break;}
 }
 $po++;
}
}
echo $arr[0],$arr[1],$arr[2];
//pp
?>
