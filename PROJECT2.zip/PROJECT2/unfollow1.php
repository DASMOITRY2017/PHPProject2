<?php
session_start();
require_once('connection.php');
$owner=$_SESSION['uid'];
$frd=$_GET['id'];

$query2="SELECT * from user_table  WHERE user_id='$frd'"; 
 if($result2=mysql_query($query2)){
     while($res_list2=mysql_fetch_assoc($result2))
	 {
	 $nlike=$res_list2['totallike'];
}
}
$query = "DELETE FROM followerlist WHERE ownerid='$owner' AND followingid='$frd'";
if( mysql_query($query))
{
  $q="insert into unfollowlist (idofowner,nf_id,totallike_nf) values ('$owner','$frd','$nlike')";
$res=mysql_query($q);
		if($res){
header("Location:following.php");
exit;
}
}
?>