<?php
	 session_start();
	 error_reporting(0);
	 include('db.php');
require_once("connection.php");
$session_id=$_SESSION['uid'];
$name=$_SESSION['uname'];
$var=$_GET['id'];
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<title>Home</title>
	
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet" />
	<link href="assets/css/get-shit-done.css" rel="stylesheet" />  
    <link href="assets/css/demo.css" rel="stylesheet" /> 
    
    <!--     Font Awesome     -->
    <link href="bootstrap3/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>
	 <style>
	 html
{height:100%;width:100%;}
	body{ background-color:#480000;
	height:100%;width:100%;
	}
	
	#post {
		float:left;
		width:1140px;
		height:720px;
		padding:70px;
		
		border: 2px solid #606;
		border-top:none;
			 border-top-right-bottom-radius: 2em;
	}
	body{ background-color:#480000
	}
	.preview
{
width:105px;
border:solid 0px #dedede;
padding:0px;
}
#preview
{
color:#cc0000;
font-size:12px
}
	#main1 {
		float:left;
		width:270px;
        height:10000px;
		padding-top:40px;
		padding:25px;
   	    border: 2px solid #480000;
   	    border-top:none;
		 border-top-right-bottom-radius: 2em;
	}
	#main2 {
		float:left;
		width:870px;
		 height:10000px;
		padding:70px;
		
		border: 2px solid #480000;
		border-top:none;
			 border-top-right-bottom-radius: 2em;
	}
	#one
	{
	width:230px;
	float:left;
	height:100px;
	}
.fileUpload {
	position: relative;
	overflow: hidden;
	margin: 10px;
}
.fileUpload input.upload {
	position: absolute;
	top: 0;
	right: 0;
	margin: 0;
	padding: 0;
	font-size: 20px;
	cursor: pointer;
	opacity: 0;
	filter: alpha(opacity=0);
}
textarea.no
{
  
  width:600px;
  height:150px;
}
#postt
{
background-color: white;
   
    padding: 15px;
    border: 0px solid #C8C8C8;
    margin: 5px;
}


	</style>
	
  <script type="text/javascript">
  function test1(a)
  {
  alert(a);
  }
function test(id)
{
$.ajax({
url:"update.php",
type:"POST",
data:{'postid':id},
success:function(data)
{
alert(ok);
}
}
);
}
function autogrow(oField)
{
  if(oField.scrollHeight>oField.clientHeight)
  {
  oField.style.height=oField.scrollHeight+"px";
  }
}
</script>  
</head>
<body >
<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#101010";>
  <div class="container">
    <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                    <span class="icon-bar"></i>  </span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="assets/img/5.jpg" alt="">
                </a>
            </div>
			<div class="navbar-header">
      
       <a class="navbar-brand" href="#">PhotoStrap</a>
	  <ul class="nav navbar-nav">
        <li><a href="home_page3.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
        <li><a href="profile_page.php"><span class="glyphicon glyphicon-th"></span> Profile</a></li>
		 <li><a href="follow_list.php"><span class="glyphicon glyphicon-user"></span> Followlist</a></li>
      </ul>
    </div>
    <div>
      <ul class="nav navbar-nav navbar-right">
	    <li><a href="notification.php"><span class="glyphicon glyphicon-bell"></span> Notification</a></li>
	    <li><a href="message.php"><span class="glyphicon glyphicon-envelope"></span> Message</a></li>
        <li><a href="first_page.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<br> <br> <br> 
<div class="container" >
  <div class="row">
    
   <div class="col-md-12"> 
      
      <div class="panel">
        <div class="panel-body">
          <div class="row"> 
    
    <div id="main1" style="background-color:#F0F0F0">
	<br><br>
	<?php	echo '&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'&nbsp'.'<p style="font-size:25px;color:blue;">'."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".$name.'</p>'; ?>
	<button type="button" class="btn btn-link  btn-lg" style="float:left;" ><span class="glyphicon glyphicon-camera"></span><a href="home_page.php"> upload photo</a></button>
	
		
</div>

<div id="main2"  style="background-color:#F0F0F0">
<?php
$q="SELECT * FROM post where photopost_id='$var'";
$r=mysql_query("$q");
$res=mysql_fetch_assoc($r);

$inc=$res['count_views'];
$inc=$inc+1;
$query="UPDATE post SET count_views='$inc' WHERE photopost_id='$var'";
//echo $query;
mysql_query($query);

?>
<span id='preview'>
<?php
$idd=$res['user_id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "photostrap";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT profile_pic FROM user_table WHERE user_id='$idd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row5 = $result->fetch_assoc()) {
	echo "&nbsp"."&nbsp"."<img src='uploads/".$row5["profile_pic"]."'  class='preview' width='5' height='80' >"."&nbsp";
    }
} else {
    echo "0 results";
}
//$conn->close();

?>

</span>  
<?php	
if($res['post_text']==NULL)
{
?>


<a style="font-size:28px;text-decoration:none;color:#000099" href="otherprofile.php?id=<?php echo urlencode($res['user_id']);?>"> <?php echo $res['user_name'];?> </a><br>
<div id="postt">
<img src="public.jpg"  width="70" height="38"><p style="font-size:12px;margin:0px;padding:0px;" ><?php echo $res['local'];?></p><br>
<?php 
 
echo '<p style="font-size:20px;margin:0px;padding:0px;" >'.$res['adetails'].'</p>';
echo "</br>";?>
<a href="pic_page.php?id=<?php echo $res['photopost_id']; ?>">
<?php
  echo "<img src=bring_photo.php?ano=".$res['photopost_id']." width=380 height=400/>".'<br>'.'<br>';
 ?>
 </a>
 </div>
 
 <?php
 $flag=1;
$q6="SELECT * FROM uff where uffpostid='$var'"; 
$r6=mysql_query("$q6");

while($row6=mysql_fetch_assoc($r6))
{
if($row6['ufflike']==$_SESSION['uid'])
 {  
    $flag=0;
    break;
 }
}
if($flag==1){
?>
 
 <a style="color:blue"  href="countlikephoto.php?id=<?php echo $res['photopost_id'];?>" >LIKE </a> 
 
 <?php 
 }
 else
 {?>
  <a style="color:blue"  href="unlike.php?id=<?php echo $res['photopost_id'];?>" >UNLIKE </a> <?php
 }
  echo '<p style="color:blue;">'." ".$res['count_like']." Likes "."&nbsp"."&nbsp".$res['count_views']." Views";
  }
  $potaka=1;
  if($res['count_comment']<=2)
  {
  $potaka=0;
  }
 
  ?> 
  
  <div id="partial">
  <?php if($potaka==1){ ?>
  <p >Top Comments</p> <?php } ?>
  <?php
  
  $pid=$res['photopost_id'];
$s1="SELECT * FROM commentofposts where id_post='$pid' ORDER BY postcomment_id desc LIMIT 0,2";
$m=mysql_query("$s1");
while($sow=mysql_fetch_assoc($m))
{
?>
<div class="panel panel-default">

  <div class="panel-heading">
  <a href="otherprofile.php?id=<?php echo $sow['id_user'] ?>"><?php echo $sow['name_user']; ?></a><a href="deletecomment.php?id=<?php echo $sow['postcomment_id'] ?>" style="text-decoration:none;"><?php echo "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp".
  "Delete Comment"; ?></a></div>
  <div class="panel-body">
<?php echo $sow['text_comment']; ?>

<p class="text-muted small" style="padding-top:15px"><?php 
$d=(strtotime($sow['time']));
 echo date('d ',$d);
echo date('F,Y',$d);
echo " at ";
echo date('h:m:s',$d);

?></p>
  </div>
</div>
<?php
// var_dump($comment);
}

?>
  </div>

 <div id="commentplace">
 <?php if($potaka==1){ ?>
 <div id="buttonhide"><button class="btn btn-primary" id="btnShow">Show all <?php echo $res['count_comment']-'2'; ?> previous comments</button></div> <?php } ?> <br>
<div id="foo" style="display:none;">
  <?php
  
  $pid=$res['photopost_id'];
$s1="SELECT * FROM commentofposts where id_post='$pid' ORDER BY postcomment_id";
$m=mysql_query("$s1");
while($sow=mysql_fetch_assoc($m))
{
?>
<div class="panel panel-default">

  <div class="panel-heading">
  <a href="otherprofile.php?id=<?php echo $sow['id_user'] ?>"><?php echo $sow['name_user']; ?></a><a href="deletecomment.php?id=<?php echo $sow['postcomment_id'] ?>" style="text-decoration:none;"><?php echo "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp"."&nbsp".
  "Delete Comment"; ?></a></div>
  <div class="panel-body">
<?php echo $sow['text_comment']; ?>

<p class="text-muted small" style="padding-top:15px"><?php 
$d=(strtotime($sow['time']));
 echo date('d ',$d);
echo date('F,Y',$d);
echo " at ";
echo date('h:m:s',$d);

?></p>
  </div>
</div>
<?php
// var_dump($comment);
}

?>


</div> 
</div>
<form id="commentform" action="addcomment.php" method="post" >
<div class="form-group">
<textarea id="comment" name="commentarea" placeholder="Enter your comment..." class="form-control"></textarea>
</div>
<input type="number" name="postid" value="<?php echo $var; ?>" hidden />
<input type="submit" name="submit" id="formsubmit" value="Comment"
class="btn btn-primary"/>
</form>
  <script>
<!--$('document').ready(function() {
$('document').ready(function(){
  $('#formsubmit').click(function(event){ //or you can use on() instead of click()
event.preventDefault();
 var submit = $('#formsubmit');
  var x=$('#commentform').serializeArray();   
    var form = $('#commentform');

  console.log(x);
   $.ajax({
	url: 'addcomment.php',
	type: 'POST',
	cache:false,
	data:x,
	beforeSend: function()
	{
        // change submit button value text and disabled it
        submit.val('Submitting...').attr('disabled', 'disabled');
      },
		//console.log(typeof(data[0]));
				//console.log(typeof(data.final));

		success: function(data){
        // Append with fadeIn see http://stackoverflow.com/a/978731
        var item = $(data).hide().fadeIn(800);
        $('#commentplace').append(item);

        // reset form and button
        form.trigger('reset');
        submit.val('Comment').removeAttr('disabled');
      },
      error: function(e){
        alert(e);
      }

	});
    });
  //return false;
  });
</script>
 <script> 
$('#btnShow').click(function(){
   $('#foo').show("slow");
   $('#partial').hide("slow");
   $('#buttonhide').hide("slow");
});
  
 </script> 						

	</div> 
       <!--     <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> -->
          </div>
          
         
          
          
        
          
        </div>
      </div>
                                                                                       
	                                                
                                                      
   	</div><!--/col-12-->
  </div>
</div>


<!-- end main -->
     

</body>

    <script src="jquery/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/jquery-ui-1.10.4.custom.min.js" type="text/javascript"></script>

	<script src="bootstrap3/js/bootstrap.js" type="text/javascript"></script>
	<script src="assets/js/gsdk-checkbox.js"></script>
	<script src="assets/js/gsdk-radio.js"></script>
	<script src="assets/js/gsdk-bootstrapswitch.js"></script>
	<script src="assets/js/get-shit-done.js"></script>
	
    <script src="assets/js/custom.js"></script>

<script type="text/javascript">
         
    $('.btn-tooltip').tooltip();
    $('.label-tooltip').tooltip();
    $('.pick-class-label').click(function(){
        var new_class = $(this).attr('new-class');  
        var old_class = $('#display-buttons').attr('data-class');
        var display_div = $('#display-buttons');
        if(display_div.length) {
        var display_buttons = display_div.find('.btn');
        display_buttons.removeClass(old_class);
        display_buttons.addClass(new_class);
        display_div.attr('data-class', new_class);
        }
    });
    $( "#slider-range" ).slider({
		range: true,
		min: 0,
		max: 500,
		values: [ 75, 300 ],
	});
	$( "#slider-default" ).slider({
			value: 70,
			orientation: "horizontal",
			range: "min",
			animate: true
	});
	$('.carousel').carousel({
      interval: 4000
    });
      
    
</script>
</html>