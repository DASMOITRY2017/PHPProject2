<?php     
require_once('connection.php');
$postid=$_POST['postid'];
header("Location:home_page3.php");
exit;
?>