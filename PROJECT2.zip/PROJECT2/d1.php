
 <form style=" width:100%;
height:450px;
margin:auto;
position:relative;">
				  
<legend>Comment</legend>

<input style=" width:80%;height:25px;" type="text"   id="cmnt" value=""></p>
<p><input type="submit" value="Upload" onClick="post();" ></p>

				  
				   </form>
				   <div id="result"></div>
				   <script type="text/javascript">

function post()
{

var age = $('#cmnt').val();
$.post('validate.php',{comment:age},
function(data){
if(data=="1")
$('#result').html("dhur");
});


}
</script> 
