<?php
session_start();
require_once('connection.php');
$owner=$_SESSION['uid'];
$pid=$_GET['id'];
$name=$_SESSION['uname'];
$query2="SELECT * from post  WHERE photopost_id='$pid'"; 
 $result2=mysql_query($query2);
     $res_list2=mysql_fetch_assoc($result2);
$whosename=$res_list2['user_name'];
$whoseid=$res_list2['user_id'];
$inc=$res_list2['count_share'];
$inc=$inc+1;
$query1="UPDATE post SET count_share='$inc' WHERE photopost_id='$pid'";
//echo $query;
if(mysql_query($query1)){

$query="insert into share
  (whoshared_id,whoshared_name,whosepost_id,whosepost_name,date,sharedid) values ('{$owner}','{$name}','{$whoseid}','{$whosename}',CURRENT_TIMESTAMP,'{$pid}')";
  if(mysql_query($query))
  {
      header("Location:home_page3.php");
	  exit;
  }
  else{
 echo mysql_error();}
 }