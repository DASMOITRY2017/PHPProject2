
	 <?php
	 session_start();
	 error_reporting(0);
require_once("connection.php");
$name=$_POST["user_name"];
$password=$_POST["password"];

$query="SELECT * FROM user_table WHERE user_name='$name'";

$result=mysql_query($query);
$row=mysql_fetch_assoc($result);
if($name == $row["user_name"]){
	if($row["password"]==$password){
	$_SESSION['uid']=$row['user_id'];
	$_SESSION['uname']=$row['name'];
	header("Location:home_page3.php");
exit;
	
	}	
	else
	  echo "wrong password";
}

else
{
     echo  "sorry password and email doesn't match";
}


	
	 
	 
	 
	 
?>