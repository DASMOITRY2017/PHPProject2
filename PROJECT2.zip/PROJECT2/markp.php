
<?php session_start();
	 error_reporting(0);
	 include('db.php');
require_once("connection.php");
$session_id=$_SESSION['uid'];
$name=$_SESSION['uname'];
$var=$_GET['id'];


$query = "DELETE FROM recentmessage WHERE sender_id='$var' AND receiver_id='$session_id' OR sender_id='$session_id' AND receiver_id='$var'";
$res= mysql_query($query);

$q="SELECT * FROM messagecount where meuser_id='$session_id'";
$r=mysql_query("$q");
$res=mysql_fetch_assoc($r);
$inc=$res['countme'];
$inc=$inc-1;
$sql="UPDATE messagecount SET countme='$inc' WHERE meuser_id='$session_id'";
if(mysql_query($sql))
{

header("Location:recentmessage.php");
exit;

}
?>